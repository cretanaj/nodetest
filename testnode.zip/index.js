const http = require('http');

const server = http.createServer((req, res) => {
	res.writeHead(200, { 'Content-Type': 'text/html' });
	res.end('<h1>Hola mundo</h1>');
});

const PORT = 3002;
server.listen(PORT, () => {
	console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
